---
title: "Bernardo Sousa"
---

Welcome to my minimalist academic portfolio.
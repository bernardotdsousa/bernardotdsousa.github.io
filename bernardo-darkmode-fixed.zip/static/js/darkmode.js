window.addEventListener("DOMContentLoaded", () => {
  const toggle = document.getElementById("dark-toggle");
  const icon = document.getElementById("dark-icon");
  const root = document.documentElement;

  function setTheme(theme) {
    root.setAttribute("data-theme", theme);
    localStorage.setItem("theme", theme);
    icon.textContent = theme === "dark" ? "⚫" : "⚪";
  }

  function initTheme() {
    const stored = localStorage.getItem("theme");
    if (stored) {
      setTheme(stored);
    } else {
      const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
      setTheme(prefersDark ? "dark" : "light");
    }
  }

  toggle?.addEventListener("click", () => {
    const current = root.getAttribute("data-theme");
    const next = current === "dark" ? "light" : "dark";
    setTheme(next);
  });

  initTheme();
});